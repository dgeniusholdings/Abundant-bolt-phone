/*
# Storefront Products Table (Manual + Imported)

## Overview
Creates a unified `storefront_products` table that holds products visible on the storefront.
Products can originate from two sources:
1. Imported from `supplier_products` (synced from dropshipping platforms)
2. Manually created by the admin

## New Table: storefront_products

- id: UUID primary key
- source_type: 'manual' | 'imported' — distinguishes origin
- supplier_product_id: FK to supplier_products (nullable, only for imported products)
- title: Product name
- description: Full description (markdown supported)
- category: Product category
- price: Current selling price (can be overridden from supplier_price)
- original_price: Original/compare-at price for showing discounts
- cost: What we pay (supplier_price for imported, 0 for manual)
- images: Array of image URLs
- variants: JSONB array of {sku, option, price, stock}
- inventory: Total stock count (tracked manually)
- is_active: Whether product shows on storefront
- is_featured: Whether product appears in featured section
- is_manual: Convenience boolean (true for manual products)
- metadata: JSONB for custom attributes (specs, tags, etc.)
- created_at / updated_at: Timestamps

## Security
- RLS enabled with anon + authenticated access (single-tenant admin)

## Notes
1. A `supplier_product_id` is only set for imported products.
2. Manual products have `source_type = 'manual'` and `supplier_product_id = null`.
3. The `variants` JSONB allows multi-SKU products without a separate variants table.
4. Imported products will receive data from parent supplier_products records but
   store local overrides (e.g., custom retail price) in this table.
*/

-- ─────────────────────────────────────────────
-- STOREFRONT PRODUCTS
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS storefront_products (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_type         text NOT NULL DEFAULT 'manual' CHECK (source_type IN ('manual', 'imported')),
  supplier_product_id uuid REFERENCES supplier_products(id) ON DELETE SET NULL,
  title               text NOT NULL,
  description         text,
  category            text,
  price               decimal(12,2) NOT NULL,
  original_price      decimal(12,2),
  cost                decimal(12,2) NOT NULL DEFAULT 0,
  images              text[] NOT NULL DEFAULT '{}',
  variants            jsonb NOT NULL DEFAULT '[]',
  inventory           integer NOT NULL DEFAULT 0,
  sku                 text,
  weight_kg           decimal(8,3),
  is_active           boolean NOT NULL DEFAULT true,
  is_featured         boolean NOT NULL DEFAULT false,
  is_manual           boolean NOT NULL DEFAULT false,
  metadata            jsonb NOT NULL DEFAULT '{}',
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_storefront_products_category ON storefront_products(category);
CREATE INDEX IF NOT EXISTS idx_storefront_products_active ON storefront_products(is_active);
CREATE INDEX IF NOT EXISTS idx_storefront_products_featured ON storefront_products(is_featured);
CREATE INDEX IF NOT EXISTS idx_storefront_products_source ON storefront_products(source_type);

-- Partial unique index: only one storefront product per supplier_product
CREATE UNIQUE INDEX IF NOT EXISTS idx_storefront_unique_supplier_product
  ON storefront_products (supplier_product_id)
  WHERE supplier_product_id IS NOT NULL;

-- RLS
ALTER TABLE storefront_products ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_storefront" ON storefront_products;
CREATE POLICY "anon_select_storefront" ON storefront_products FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_storefront" ON storefront_products;
CREATE POLICY "anon_insert_storefront" ON storefront_products FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_storefront" ON storefront_products;
CREATE POLICY "anon_update_storefront" ON storefront_products FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_storefront" ON storefront_products;
CREATE POLICY "anon_delete_storefront" ON storefront_products FOR DELETE TO anon, authenticated USING (true);
